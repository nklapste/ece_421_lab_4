class Aquatic
    def speak
        puts "cannot speak"
    end

    def sleep
        puts "cannot sleep"
    end

    def eat
        puts "cannot eat"
    end
    
    def where
        puts "we live in water"
    end
end
